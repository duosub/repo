import re

def parse_srt(file_path):
    """Читает SRT файл и разбивает его на блоки (индекс, время, текст)"""
    with open(file_path, 'r', encoding='utf-8-sig') as f:
        content = f.read()
    
    # Регулярное выражение для поиска блоков субтитров
    # Разделяем по двойному переносу строки
    blocks = re.split(r'\n\s*\n', content.strip())
    parsed_blocks = []
    
    for block in blocks:
        lines = block.split('\n')
        if len(lines) >= 3:
            index = lines[0]
            timing = lines[1]
            # Объединяем текст, если он разбит на несколько строк
            text = " ".join(lines[2:])
            parsed_blocks.append({
                "index": index,
                "timing": timing,
                "text": text
            })
            
    return parsed_blocks

def save_dual_srt(original_blocks, translated_texts, output_path):
    """Сохраняет новый файл, объединяя перевод и оригинал"""
    with open(output_path, 'w', encoding='utf-8') as f:
        for i, block in enumerate(original_blocks):
            f.write(f"{block['index']}\n")
            f.write(f"{block['timing']}\n")
            
            # Логика DuoSub: Перевод сверху, Оригинал снизу
            # (Вы можете поменять их местами, если нужно)
            translation = translated_texts[i] if i < len(translated_texts) else "..."
            f.write(f"{translation}\n")
            f.write(f"{block['text']}\n\n")
