
UI_LANGS = {
    "en": {
        "name": "English", "title": "DuoSuob Maker", "open": "Open File", "run": "Start Translation", 
        "save": "Save / Download", "log": "Event Log", "preview": "Preview", "copy": "Copy Results",
        "loading": "Loading file", "init": "Initializing translation", "lines": "total lines",
        "block": "Translating block", "assembling": "Assembling dual lines", "done": "All processes completed successfully",
        "saved": "Saved successfully", "selected": "File selected", "home": "Home Page",
        "hint_open": "Select a subtitle file (srt, vtt, ass, sub, txt)",
        "hint_run": "Start the translation process",
        "hint_save": "Save the result to a new file",
        "hint_donate": "Support the developer (opens: https://duosub.github.io/donate/)",
        "hint_copy": "Copy everything from preview to clipboard"
    },
    "ru": {
        "name": "Русский", "title": "DuoSuob Maker", "open": "Открыть файл", "run": "Запустить перевод", 
        "save": "Скачать результат", "log": "Лог событий", "preview": "Предпросмотр", "copy": "Копировать результат",
        "loading": "Загрузка файла", "init": "Инициализация перевода", "lines": "всего строк",
        "block": "Перевод блока", "assembling": "Сборка двухстрочных субтитров", "done": "Все процессы завершены успешно",
        "saved": "Успешно сохранено", "selected": "Файл выбран", "home": "Домашняя страница",
        "hint_open": "Выбрать файл субтитров (srt, vtt, ass, sub, txt)",
        "hint_run": "Начать процесс перевода",
        "hint_save": "Сохранить результат в новый файл",
        "hint_donate": "Поддержать разработчика (откроется: https://duosub.github.io/donate/)",
        "hint_copy": "Копировать всё из предпросмотра в буфер обмена"
    },
    "it": {
        "name": "Italiano", "title": "DuoSuob Maker", "open": "Apri file", "run": "Avvia traduzione", 
        "save": "Scarica risultato", "log": "Log eventi", "preview": "Anteprima", "copy": "Copia risultati",
        "loading": "Caricamento file", "init": "Inizializzazione traduzione", "lines": "linee totali",
        "block": "Traduzione blocco", "assembling": "Assemblaggio linee doppie", "done": "Processi completati con successo",
        "saved": "Salvato con successo", "selected": "File selezionato", "home": "Pagina iniziale",
        "hint_open": "Seleziona un file di sottotitoli", "hint_run": "Avvia la traduzione",
        "hint_save": "Salva il file", "hint_donate": "Supporta lo sviluppatore", "hint_copy": "Copia negli appunti"
    },
    "fr": {
        "name": "Français", "title": "DuoSuob Maker", "open": "Ouvrir", "run": "Traduire", 
        "save": "Télécharger", "log": "Journal", "preview": "Aperçu", "copy": "Copier",
        "loading": "Chargement", "init": "Initialisation", "lines": "lignes au total",
        "block": "Traduction du bloc", "assembling": "Assemblage", "done": "Terminé avec succès",
        "saved": "Enregistré", "selected": "Fichier sélectionné", "home": "Accueil",
        "hint_open": "Choisir un fichier", "hint_run": "Lancer la traduction",
        "hint_save": "Enregistrer le fichier", "hint_donate": "Soutenir le développeur", "hint_copy": "Copier le texte"
    },
    "de": {
        "name": "Deutsch", "title": "DuoSuob Maker", "open": "Datei öffnen", "run": "Übersetzung starten", 
        "save": "Herunterladen", "log": "Ereignisprotokoll", "preview": "Vorschau", "copy": "Kopieren",
        "loading": "Laden", "init": "Initialisierung", "lines": "Zeilen insgesamt",
        "block": "Block übersetzen", "assembling": "Zusammenbau", "done": "Erfolgreich abgeschlossen",
        "saved": "Erfolgreich gespeichert", "selected": "Datei ausgewählt", "home": "Startseite",
        "hint_open": "Datei auswählen", "hint_run": "Übersetzung starten",
        "hint_save": "Datei speichern", "hint_donate": "Entwickler unterstützen", "hint_copy": "In Zwischenablage kopieren"
    },
    "es": {
        "name": "Español", "title": "DuoSuob Maker", "open": "Abrir archivo", "run": "Iniciar traducción", 
        "save": "Descargar", "log": "Registro", "preview": "Vista previa", "copy": "Copiar",
        "loading": "Cargando", "init": "Iniciando", "lines": "líneas en total",
        "block": "Traduciendo bloque", "assembling": "Ensamblando", "done": "Completado con éxito",
        "saved": "Guardado con éxito", "selected": "Archivo seleccionado", "home": "Inicio",
        "hint_open": "Seleccionar archivo", "hint_run": "Iniciar proceso",
        "hint_save": "Guardar resultado", "hint_donate": "Apoyar al desarrollador", "hint_copy": "Copiar al portapapeles"
    }
}


SUB_LANGS = {
    "af": "Afrikaans", "sq": "Albanian (Shqip)", "am": "Amharic (አማርኛ)", "ar": "Arabic (العربية)",
    "hy": "Armenian (Հայերեն)", "az": "Azerbaijani (Azərbaycan)", "eu": "Basque (Euskara)",
    "be": "Belarusian (Беларуская)", "bn": "Bengali (বাংলা)", "bs": "Bosnian (Bosanski)",
    "bg": "Bulgarian (Български)", "ca": "Catalan (Català)", "zh-CN": "Chinese (Simplified) (简体中文)",
    "zh-TW": "Chinese (Traditional) (繁體中文)", "hr": "Croatian (Hrvatski)", "cs": "Czech (Čeština)",
    "da": "Danish (Dansk)", "nl": "Dutch (Nederlands)", "en": "English", "et": "Estonian (Eesti)",
    "tl": "Filipino (Tagalog)", "fi": "Finnish (Suomi)", "fr": "French (Français)", "de": "German (Deutsch)",
    "el": "Greek (Ελληνικά)", "he": "Hebrew (עبری)", "hi": "Hindi (हिन्दी)", "hu": "Hungarian (Magyar)",
    "is": "Icelandic (Íslenska)", "id": "Indonesian (Bahasa Indonesia)", "it": "Italiano (Italian)",
    "ja": "Japanese (日本語)", "ko": "Korean (한국어)", "lv": "Latvian (Latviešu)", "lt": "Lithuanian (Lietuvių)",
    "no": "Norwegian (Norsk)", "pl": "Polish (Polski)", "pt": "Portuguese (Português)",
    "ro": "Romanian (Română)", "ru": "Russian (Русский)", "sr": "Serbian (Српски)", "sk": "Slovak (Slovenčina)",
    "sl": "Slovenian (Slovenščina)", "es": "Spanish (Español)", "sv": "Swedish (Svenska)", "th": "Thai (ไทย)",
    "tr": "Turkish (Türkçe)", "uk": "Ukrainian (Українська)", "vi": "Vietnamese (Tiếng Việt)"
}
