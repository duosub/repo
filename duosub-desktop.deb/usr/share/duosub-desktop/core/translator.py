import subprocess
import shlex
import os
import time
import re

class Translator:
    def __init__(self, engine="google"):
        self.engine = engine

    def clean_tags(self, text):
        # Удаляем теги типа {\i1}, {\fnArial} и т.д. для корректного перевода
        return re.sub(r'\{.*?\}', '', text)

    def translate_batch(self, text_list, target_lang, source_lang="auto"):
        if not text_list:
            return [], ""

        # Правило: Очищаем оригинальный текст от тегов перед переводом
        cleaned_batch = [self.clean_tags(t) for t in text_list]
        
        separator = " @@@ "
        combined_text = separator.join([t.replace("\n", " ") for t in cleaned_batch])
        
        # Для Yandex/Bing лучше использовать небольшую задержку, чтобы избежать 403
        if self.engine in ["yandex", "bing"]:
            time.sleep(1.5) 

        cmd = f'trans -b -e {self.engine} -to {target_lang} "{combined_text}"'
        
        try:
            env = os.environ.copy()
            env["LC_ALL"] = "C.UTF-8"
            
            process = subprocess.Popen(
                shlex.split(cmd),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env
            )
            stdout, stderr = process.communicate(timeout=60)

            if process.returncode == 0:
                decoded_output = stdout.decode('utf-8', errors='replace').strip()
                # Убираем возможные артефакты, которые иногда вставляют Bing/Yandex
                decoded_output = decoded_output.replace("233b", "").replace("", "")
                
                translated_parts = [t.strip() for t in decoded_output.split("@@@")]
                
                while len(translated_parts) < len(text_list):
                    translated_parts.append("[error: mismatch]")
                
                return translated_parts[:len(text_list)], cmd
            else:
                return None, f"Engine Error: {stderr.decode('utf-8', errors='replace')[:100]}"
        except Exception as e:
            return None, f"System Error: {str(e)}"
