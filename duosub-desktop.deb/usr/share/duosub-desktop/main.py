import sys, os, locale, re, time, subprocess, shlex

# 1. Настройка путей (ДО всех остальных импортов)
basedir = os.path.dirname(os.path.realpath(__file__))
if basedir not in sys.path:
    sys.path.insert(0, basedir)

# 2. Попытка импорта зависимостей
try:
    import pysubs2
    from PyQt6.QtWidgets import (QApplication, QMainWindow, QPushButton, QVBoxLayout, QHBoxLayout,
                                 QWidget, QProgressBar, QLabel, QFileDialog, QComboBox, QTextEdit, QMenu, QSpinBox)
    from PyQt6.QtCore import Qt, QThread, pyqtSignal, QUrl, QWaitCondition, QMutex
    from PyQt6.QtGui import QDesktopServices, QAction
    
    # Импорт наших модулей из папки core
    from core.languages import UI_LANGS, SUB_LANGS
except ImportError as e:
    print(f"Критическая ошибка: не найдена зависимость! {e}")
    print("Попробуйте: pip install pyqt6 pysubs2 --break-system-packages")
    sys.exit(1)

class TranslationWorker(QThread):
    finished = pyqtSignal(object)
    log_signal = pyqtSignal(str, str)
    batch_preview = pyqtSignal(str)
    progress_update = pyqtSignal(int)

    def __init__(self, file_path, target_lang, engine, delay, batch_size, ui_texts):
        super().__init__()
        self.file_path = file_path
        self.target_lang = target_lang
        self.engine = engine
        self.delay = delay
        self.batch_size = batch_size
        self.t = ui_texts
        self._is_paused = False
        self._mutex = QMutex()
        self._condition = QWaitCondition()

    def pause(self):
        self._is_paused = True

    def resume(self):
        self._is_paused = False
        self._condition.wakeAll()

    def clean_tags(self, text):
        return re.sub(r'\{.*?\}', '', text)

    def run(self):
        try:
            self.log_signal.emit("loading", os.path.basename(self.file_path))
            subs = pysubs2.load(self.file_path, encoding="utf-8")
            texts = [line.text for line in subs]
            translated_full = []
            total = len(subs)

            for i in range(0, total, self.batch_size):
                self._mutex.lock()
                while self._is_paused:
                    self._condition.wait(self._mutex)
                self._mutex.unlock()

                if self.isInterruptionRequested(): return

                batch = texts[i : i + self.batch_size]
                
                if self.engine in ["yandex", "bing"]: 
                    time.sleep(self.delay)
                
                cleaned_batch = [self.clean_tags(t) for t in batch]
                combined_text = " @@@ ".join([t.replace("\n", " ") for t in cleaned_batch])
                cmd = f'trans -b -e {self.engine} -to {self.target_lang} "{combined_text}"'
                
                env = os.environ.copy()
                env["LC_ALL"] = "C.UTF-8"
                process = subprocess.Popen(shlex.split(cmd), stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
                stdout, stderr = process.communicate(timeout=60)

                if process.returncode == 0:
                    decoded = stdout.decode('utf-8', errors='replace').strip()
                    res = [t.strip() for t in decoded.split("@@@")]
                    while len(res) < len(batch): res.append("[error]")
                    
                    translated_full.extend(res[:len(batch)])
                    preview = ""
                    for j, t_text in enumerate(res[:len(batch)]):
                        idx = i + j
                        if idx < total:
                            line = subs[idx]
                            preview += f"{idx+1}\n{pysubs2.time.ms_to_str(line.start)} --> {pysubs2.time.ms_to_str(line.end)}\n{t_text}\n{line.text}\n\n"
                    self.batch_preview.emit(preview)
                else:
                    self.log_signal.emit("error", f"Engine error: {self.engine}")
                    translated_full.extend(["[error]"] * len(batch))
                
                self.progress_update.emit(int(((i + len(batch)) / total) * 100))

            for i, line in enumerate(subs):
                line.text = f"{translated_full[i]}\\N{line.text}" 
            self.finished.emit(subs)
        except Exception as e:
            self.log_signal.emit("error", str(e))
            self.finished.emit(None)

class DuoSuobApp(QMainWindow):
    def __init__(self):
        super().__init__()
        try: sys_lang = locale.getlocale()[0][:2]
        except: sys_lang = "en"
        self.curr_ui_code = sys_lang if sys_lang in UI_LANGS else "en"
        self.worker = None
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("DuoSuob Desktop")
        self.setMinimumSize(1000, 750)
        central = QWidget()
        self.layout = QVBoxLayout(central)

        top_bar = QHBoxLayout()
        self.lang_btn = QPushButton("🌐 " + UI_LANGS[self.curr_ui_code]['name'])
        menu = QMenu(self)
        for code, lang in UI_LANGS.items():
            action = QAction(lang['name'], self)
            action.triggered.connect(lambda chk, c=code: self.change_ui_lang(c))
            menu.addAction(action)
        self.lang_btn.setMenu(menu)

        self.btn_home = QPushButton("🏠 Home")
        self.btn_home.setFlat(True)
        self.btn_home.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://duosub.github.io")))
        
        top_bar.addWidget(self.lang_btn)
        top_bar.addStretch()
        top_bar.addWidget(self.btn_home)
        self.layout.addLayout(top_bar)

        settings = QHBoxLayout()
        self.engine_box = QComboBox()
        self.engine_box.addItems(["google", "bing", "yandex"])
        self.sub_lang_box = QComboBox()
        for code, name in SUB_LANGS.items(): self.sub_lang_box.addItem(name, code)
        self.delay_spin = QSpinBox()
        self.delay_spin.setRange(0, 10)
        self.delay_spin.setValue(2)

        settings.addWidget(QLabel("Engine:"))
        settings.addWidget(self.engine_box)
        settings.addWidget(QLabel("Target:"))
        settings.addWidget(self.sub_lang_box)
        settings.addWidget(QLabel("Pause (s):"))
        settings.addWidget(self.delay_spin)
        self.layout.addLayout(settings)

        self.btn_open = QPushButton("Open File")
        self.btn_open.clicked.connect(self.open_file)
        self.layout.addWidget(self.btn_open)

        self.pbar = QProgressBar()
        self.layout.addWidget(self.pbar)

        panes = QHBoxLayout()
        self.txt_log = QTextEdit()
        self.txt_log.setReadOnly(True)
        self.txt_preview = QTextEdit()
        self.txt_preview.setReadOnly(True)
        panes.addWidget(self.txt_log, 4)
        panes.addWidget(self.txt_preview, 6)
        self.layout.addLayout(panes)

        self.btn_run = QPushButton("Start Translation")
        self.btn_run.setEnabled(False)
        self.btn_run.setMinimumHeight(50)
        self.btn_run.clicked.connect(self.toggle_translation)
        
        self.btn_save = QPushButton("Save")
        self.btn_save.setEnabled(False)
        self.layout.addWidget(self.btn_run)
        self.layout.addWidget(self.btn_save)

        self.setCentralWidget(central)
        self.update_ui_texts()

    def change_ui_lang(self, code):
        self.curr_ui_code = code
        self.lang_btn.setText("🌐 " + UI_LANGS[code]['name'])
        self.update_ui_texts()

    def update_ui_texts(self):
        t = UI_LANGS[self.curr_ui_code]
        self.btn_open.setText(t['open'])
        if not (self.worker and self.worker.isRunning()):
            self.btn_run.setText(t['run'])
        self.btn_save.setText(t['save'])
        self.btn_home.setText("🏠 " + t.get('home', 'Home'))

    def open_file(self):
        f, _ = QFileDialog.getOpenFileName(self, "Open", "", "Subs (*.srt *.vtt *.ass *.sub *.txt)")
        if f:
            self.selected_file = f
            self.btn_run.setEnabled(True)

    def toggle_translation(self):
        if self.worker and self.worker.isRunning():
            if self.worker._is_paused:
                self.worker.resume()
                self.btn_run.setText("⏸ Pause")
            else:
                self.worker.pause()
                self.btn_run.setText("▶ Resume")
        else:
            self.start_process()

    def start_process(self):
        self.txt_preview.clear()
        self.pbar.setValue(0)
        self.btn_run.setText("⏸ Pause")
        self.worker = TranslationWorker(
            self.selected_file, self.sub_lang_box.currentData(),
            self.engine_box.currentText(), self.delay_spin.value(),
            8, UI_LANGS[self.curr_ui_code]
        )
        self.worker.progress_update.connect(self.pbar.setValue)
        self.worker.log_signal.connect(lambda k, d: self.txt_log.append(f"[{k}] {d}"))
        self.worker.batch_preview.connect(lambda t: self.txt_preview.append(t))
        self.worker.finished.connect(self.on_finished)
        self.worker.start()

    def on_finished(self, subs):
        self.update_ui_texts()
        if subs:
            self.current_subs = subs
            self.btn_save.setEnabled(True)
            try:
                self.btn_save.clicked.disconnect()
            except:
                pass
            self.btn_save.clicked.connect(self.save_file)

    def save_file(self):
        ext = os.path.splitext(self.selected_file)[1]
        name = f"{os.path.splitext(os.path.basename(self.selected_file))[0]}_{self.sub_lang_box.currentData()}{ext}"
        path, _ = QFileDialog.getSaveFileName(self, "Save", name, f"Subs (*{ext})")
        if path: self.current_subs.save(path)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = DuoSuobApp()
    window.show()
    sys.exit(app.exec())
